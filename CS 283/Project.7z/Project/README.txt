Run makefile

In the folder the extra files should be there.
To test that program compiles, write gcc -g program.c
Not included in makefile because of showing that it can compile.
Most of the testing can be done on myspin.c because it's a wait.
Not sure what else to write since according to the instructions you are going to through testing so I shouldn't force you to do some testing.

To leave, type quit.