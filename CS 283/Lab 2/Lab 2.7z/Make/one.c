#include "one.h"
#include "ext.h"

int one ()
 {
  printf("one\n");
  two();
  return(1);
 }
 