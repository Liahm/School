#include "one.h"
int three(); //This is useless

int two ()
 {
  printf("two\n");
  three();
  return(1);
 }
 